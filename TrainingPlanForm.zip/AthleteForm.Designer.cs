﻿namespace KickBlast_Judo_APP_REMAKE
{
    partial class AthleteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadData = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtCurrentWeight = new System.Windows.Forms.TextBox();
            this.txtAthleteName = new System.Windows.Forms.TextBox();
            this.lblCurrentWeight = new System.Windows.Forms.Label();
            this.lblAthleteName = new System.Windows.Forms.Label();
            this.lblWeightCategory = new System.Windows.Forms.Label();
            this.lblTrainingPlan = new System.Windows.Forms.Label();
            this.lblCompetitions = new System.Windows.Forms.Label();
            this.lblPrivateHours = new System.Windows.Forms.Label();
            this.cmbWeightCategory = new System.Windows.Forms.ComboBox();
            this.cmbTrainingPlan = new System.Windows.Forms.ComboBox();
            this.nudCompetitions = new System.Windows.Forms.NumericUpDown();
            this.nudPrivateHours = new System.Windows.Forms.NumericUpDown();
            this.dataGridViewAthletes = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudCompetitions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrivateHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAthletes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLoadData
            // 
            this.btnLoadData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoadData.Location = new System.Drawing.Point(469, 161);
            this.btnLoadData.Name = "btnLoadData";
            this.btnLoadData.Size = new System.Drawing.Size(75, 23);
            this.btnLoadData.TabIndex = 27;
            this.btnLoadData.Text = "Load Data";
            this.btnLoadData.UseVisualStyleBackColor = false;
            this.btnLoadData.Click += new System.EventHandler(this.btnLoadData_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDelete.Location = new System.Drawing.Point(383, 190);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 26;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEdit.Location = new System.Drawing.Point(469, 190);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 25;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSave.Location = new System.Drawing.Point(383, 161);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 24;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtCurrentWeight
            // 
            this.txtCurrentWeight.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentWeight.Location = new System.Drawing.Point(144, 66);
            this.txtCurrentWeight.Name = "txtCurrentWeight";
            this.txtCurrentWeight.Size = new System.Drawing.Size(158, 25);
            this.txtCurrentWeight.TabIndex = 23;
            // 
            // txtAthleteName
            // 
            this.txtAthleteName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAthleteName.Location = new System.Drawing.Point(144, 24);
            this.txtAthleteName.Name = "txtAthleteName";
            this.txtAthleteName.Size = new System.Drawing.Size(158, 25);
            this.txtAthleteName.TabIndex = 22;
            // 
            // lblCurrentWeight
            // 
            this.lblCurrentWeight.AutoSize = true;
            this.lblCurrentWeight.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentWeight.Location = new System.Drawing.Point(12, 72);
            this.lblCurrentWeight.Name = "lblCurrentWeight";
            this.lblCurrentWeight.Size = new System.Drawing.Size(112, 19);
            this.lblCurrentWeight.TabIndex = 21;
            this.lblCurrentWeight.Text = "Current Weight";
            // 
            // lblAthleteName
            // 
            this.lblAthleteName.AutoSize = true;
            this.lblAthleteName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAthleteName.Location = new System.Drawing.Point(12, 30);
            this.lblAthleteName.Name = "lblAthleteName";
            this.lblAthleteName.Size = new System.Drawing.Size(102, 19);
            this.lblAthleteName.TabIndex = 20;
            this.lblAthleteName.Text = "Athlete Name";
            // 
            // lblWeightCategory
            // 
            this.lblWeightCategory.AutoSize = true;
            this.lblWeightCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeightCategory.Location = new System.Drawing.Point(12, 110);
            this.lblWeightCategory.Name = "lblWeightCategory";
            this.lblWeightCategory.Size = new System.Drawing.Size(122, 19);
            this.lblWeightCategory.TabIndex = 28;
            this.lblWeightCategory.Text = "Weight Category";
            this.lblWeightCategory.Click += new System.EventHandler(this.lblWeightCategory_Click);
            // 
            // lblTrainingPlan
            // 
            this.lblTrainingPlan.AutoSize = true;
            this.lblTrainingPlan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrainingPlan.Location = new System.Drawing.Point(12, 147);
            this.lblTrainingPlan.Name = "lblTrainingPlan";
            this.lblTrainingPlan.Size = new System.Drawing.Size(97, 19);
            this.lblTrainingPlan.TabIndex = 29;
            this.lblTrainingPlan.Text = "Training Plan";
            // 
            // lblCompetitions
            // 
            this.lblCompetitions.AutoSize = true;
            this.lblCompetitions.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompetitions.Location = new System.Drawing.Point(12, 194);
            this.lblCompetitions.Name = "lblCompetitions";
            this.lblCompetitions.Size = new System.Drawing.Size(97, 19);
            this.lblCompetitions.TabIndex = 30;
            this.lblCompetitions.Text = "Competitions";
            // 
            // lblPrivateHours
            // 
            this.lblPrivateHours.AutoSize = true;
            this.lblPrivateHours.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrivateHours.Location = new System.Drawing.Point(193, 194);
            this.lblPrivateHours.Name = "lblPrivateHours";
            this.lblPrivateHours.Size = new System.Drawing.Size(102, 19);
            this.lblPrivateHours.TabIndex = 31;
            this.lblPrivateHours.Text = "Private Hours";
            // 
            // cmbWeightCategory
            // 
            this.cmbWeightCategory.FormattingEnabled = true;
            this.cmbWeightCategory.Location = new System.Drawing.Point(144, 111);
            this.cmbWeightCategory.Name = "cmbWeightCategory";
            this.cmbWeightCategory.Size = new System.Drawing.Size(151, 21);
            this.cmbWeightCategory.TabIndex = 32;
            // 
            // cmbTrainingPlan
            // 
            this.cmbTrainingPlan.FormattingEnabled = true;
            this.cmbTrainingPlan.Location = new System.Drawing.Point(144, 148);
            this.cmbTrainingPlan.Name = "cmbTrainingPlan";
            this.cmbTrainingPlan.Size = new System.Drawing.Size(151, 21);
            this.cmbTrainingPlan.TabIndex = 33;
            // 
            // nudCompetitions
            // 
            this.nudCompetitions.Location = new System.Drawing.Point(127, 193);
            this.nudCompetitions.Name = "nudCompetitions";
            this.nudCompetitions.Size = new System.Drawing.Size(50, 20);
            this.nudCompetitions.TabIndex = 34;
            // 
            // nudPrivateHours
            // 
            this.nudPrivateHours.Location = new System.Drawing.Point(301, 193);
            this.nudPrivateHours.Name = "nudPrivateHours";
            this.nudPrivateHours.Size = new System.Drawing.Size(50, 20);
            this.nudPrivateHours.TabIndex = 35;
            // 
            // dataGridViewAthletes
            // 
            this.dataGridViewAthletes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAthletes.Location = new System.Drawing.Point(12, 223);
            this.dataGridViewAthletes.Name = "dataGridViewAthletes";
            this.dataGridViewAthletes.Size = new System.Drawing.Size(532, 232);
            this.dataGridViewAthletes.TabIndex = 36;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(344, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 134);
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            // 
            // AthleteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(569, 467);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridViewAthletes);
            this.Controls.Add(this.nudPrivateHours);
            this.Controls.Add(this.nudCompetitions);
            this.Controls.Add(this.cmbTrainingPlan);
            this.Controls.Add(this.cmbWeightCategory);
            this.Controls.Add(this.lblPrivateHours);
            this.Controls.Add(this.lblCompetitions);
            this.Controls.Add(this.lblTrainingPlan);
            this.Controls.Add(this.lblWeightCategory);
            this.Controls.Add(this.btnLoadData);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtCurrentWeight);
            this.Controls.Add(this.txtAthleteName);
            this.Controls.Add(this.lblCurrentWeight);
            this.Controls.Add(this.lblAthleteName);
            this.Name = "AthleteForm";
            this.Text = "AthleteForm";
            ((System.ComponentModel.ISupportInitialize)(this.nudCompetitions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrivateHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAthletes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoadData;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtCurrentWeight;
        private System.Windows.Forms.TextBox txtAthleteName;
        private System.Windows.Forms.Label lblCurrentWeight;
        private System.Windows.Forms.Label lblAthleteName;
        private System.Windows.Forms.Label lblWeightCategory;
        private System.Windows.Forms.Label lblTrainingPlan;
        private System.Windows.Forms.Label lblCompetitions;
        private System.Windows.Forms.Label lblPrivateHours;
        private System.Windows.Forms.ComboBox cmbWeightCategory;
        private System.Windows.Forms.ComboBox cmbTrainingPlan;
        private System.Windows.Forms.NumericUpDown nudCompetitions;
        private System.Windows.Forms.NumericUpDown nudPrivateHours;
        private System.Windows.Forms.DataGridView dataGridViewAthletes;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}