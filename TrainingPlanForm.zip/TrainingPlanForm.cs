﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlast_Judo_APP_REMAKE
{
    public partial class TrainingPlanForm : Form
    {
        string connectionString = @"Data Source=LAPTOP-O7I0OUQ6;Initial Catalog=KickBlastJudoDB2;Integrated Security=True;";

        public TrainingPlanForm()
        {
            InitializeComponent();
            LoadTrainingPlans();
        }

        private void TrainingPlanForm_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO TrainingPlan (PlanName, WeeklyFee, DurationWeeks, Cost) VALUES (@PlanName, @WeeklyFee, @DurationWeeks, @Cost)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanName", txtPlanName.Text);
                command.Parameters.AddWithValue("@WeeklyFee", decimal.Parse (txtWeeklyFee.Text));
                command.Parameters.AddWithValue("@DurationWeeks", int.Parse(nudDurationWeeks.Text));
                command.Parameters.AddWithValue("@Cost", decimal.Parse(lblCost.Text.Replace("Rs.", "").Trim()));

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Training Plan added successfully!");
            }

            LoadTrainingPlans();
        }

        private void LoadTrainingPlans()
        {
            string query = "SELECT TrainingPlanID, PlanName, WeeklyFee, DurationWeeks, Cost FROM TrainingPlan";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewTrainingPlans.DataSource = dataTable;
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                
                decimal weeklyFee = decimal.Parse(txtWeeklyFee.Text);
                int durationWeeks = int.Parse(nudDurationWeeks.Value.ToString());

                
                decimal totalCost = weeklyFee * durationWeeks;

                
                lblCost.Text = $"Rs. {totalCost:F2}";
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid input! Please enter valid numbers for Weekly Fee and Duration Weeks.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewTrainingPlans.SelectedRows.Count > 0)
            {
                int planId = Convert.ToInt32(dataGridViewTrainingPlans.SelectedRows[0].Cells["TrainingPlanID"].Value);

                string query = "DELETE FROM TrainingPlan WHERE TrainingPlanID = @TrainingPlanID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@TrainingPlanID", planId);

                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Training Plan deleted!");
                }

                LoadTrainingPlans();
            }
        }
    }
}
    
