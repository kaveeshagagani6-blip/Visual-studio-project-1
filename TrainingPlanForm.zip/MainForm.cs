﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlast_Judo_APP_REMAKE
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnAthletes_Click(object sender, EventArgs e)
        {
            AthleteForm athleteForm = new AthleteForm();
            athleteForm.Show();
        }

        private void btnTrainingPlans_Click(object sender, EventArgs e)
        {
            TrainingPlanForm trainingPlanForm = new TrainingPlanForm();
            trainingPlanForm.Show();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            ReportsForm reportsForm = new ReportsForm();
            reportsForm.Show();
        }
    }
}
