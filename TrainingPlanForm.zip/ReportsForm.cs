﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KickBlast_Judo_APP_REMAKE
{
    public partial class ReportsForm : Form
    {
        string connectionString = @"Data Source=LAPTOP-O7I0OUQ6;Initial Catalog=KickBlastJudoDB2;Integrated Security=True;";
        public ReportsForm()
        {
            InitializeComponent();
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {

            string query = @"
                SELECT A.Name, A.WeightCategory, T.PlanName, T.WeeklyFee, T.DurationWeeks, T.Cost
                FROM Athlete A
                JOIN TrainingPlan T ON A.TrainingPlanID = T.TrainingPlanID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewReport.DataSource = dataTable;

                double totalRevenue = 0;
                foreach (DataRow row in dataTable.Rows)
                {
                    totalRevenue += Convert.ToDouble(row["WeeklyFee"]);
                }

                lblTotalRevenue.Text = "Total Revenue: Rs. " + totalRevenue.ToString("F2");
            }
        }

        private void btnPrintReport_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Print functionality will be implemented later!");
        }
    }
}
