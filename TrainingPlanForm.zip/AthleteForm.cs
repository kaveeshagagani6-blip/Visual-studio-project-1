﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace KickBlast_Judo_APP_REMAKE
{
    public partial class AthleteForm : Form
    {
        string connectionString = @"Data Source=LAPTOP-O7I0OUQ6;Initial Catalog=KickBlastJudoDB2;Integrated Security=True;;";
        public AthleteForm()
        {
            InitializeComponent();
            LoadAthlete();
            InitializeComboBoxes();
        }

        private void lblWeightCategory_Click(object sender, EventArgs e)
        {

        }

        private void InitializeComboBoxes()
        {
            cmbWeightCategory.Items.AddRange(new object[] { "Lightweight", "Middleweight", "Heavyweight" });
            cmbTrainingPlan.Items.AddRange(new object[] { "Beginner", "Intermediate", "Elite" });
        }

        private void LoadAthlete()
        {
            string query = "SELECT AthleteID, Name, CurrentWeight, WeightCategory, TrainingPlanID FROM Athlete";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                dataGridViewAthletes.DataSource = dataTable;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Athlete (Name, CurrentWeight, WeightCategory, TrainingPlanID) VALUES (@Name, @CurrentWeight," +
                                                 "@WeightCategory, @TrainingPlanID)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", txtAthleteName.Text);
                command.Parameters.AddWithValue("@CurrentWeight", txtCurrentWeight.Text);
                command.Parameters.AddWithValue("@WeightCategory", cmbWeightCategory.Text);
                command.Parameters.AddWithValue("@TrainingPlanID", cmbTrainingPlan.SelectedIndex + 1);

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Athlete added successfully!");
            }

            LoadAthlete();
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            string query = "SELECT AthleteID, Name, CurrentWeight, WeightCategory, TrainingPlanID FROM Athlete";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewAthletes.DataSource = dataTable;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewAthletes.SelectedRows.Count > 0)
            {
                int athleteId = Convert.ToInt32(dataGridViewAthletes.SelectedRows[0].Cells["AthleteID"].Value);

                string query = "DELETE FROM Athlete WHERE AthleteID = @AthleteID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@AthleteID", athleteId);

                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Athlete deleted!");
                }

                // Refresh DataGridView
                LoadAthlete();

            }
        }
    }
}
