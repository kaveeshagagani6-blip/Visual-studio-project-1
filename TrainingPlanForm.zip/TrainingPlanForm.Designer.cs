﻿namespace KickBlast_Judo_APP_REMAKE
{
    partial class TrainingPlanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblWeeklyFee = new System.Windows.Forms.Label();
            this.txtPlanName = new System.Windows.Forms.TextBox();
            this.txtWeeklyFee = new System.Windows.Forms.TextBox();
            this.btnLoadTrainingPlans = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dataGridViewTrainingPlans = new System.Windows.Forms.DataGridView();
            this.lblDurationWeek = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.nudDurationWeeks = new System.Windows.Forms.NumericUpDown();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTrainingPlans)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDurationWeeks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Plan Name";
            // 
            // lblWeeklyFee
            // 
            this.lblWeeklyFee.AutoSize = true;
            this.lblWeeklyFee.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeeklyFee.Location = new System.Drawing.Point(21, 60);
            this.lblWeeklyFee.Name = "lblWeeklyFee";
            this.lblWeeklyFee.Size = new System.Drawing.Size(89, 19);
            this.lblWeeklyFee.TabIndex = 1;
            this.lblWeeklyFee.Text = "Weekly Fee";
            // 
            // txtPlanName
            // 
            this.txtPlanName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlanName.Location = new System.Drawing.Point(124, 20);
            this.txtPlanName.Name = "txtPlanName";
            this.txtPlanName.Size = new System.Drawing.Size(158, 25);
            this.txtPlanName.TabIndex = 2;
            // 
            // txtWeeklyFee
            // 
            this.txtWeeklyFee.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeeklyFee.Location = new System.Drawing.Point(124, 60);
            this.txtWeeklyFee.Name = "txtWeeklyFee";
            this.txtWeeklyFee.Size = new System.Drawing.Size(158, 25);
            this.txtWeeklyFee.TabIndex = 3;
            // 
            // btnLoadTrainingPlans
            // 
            this.btnLoadTrainingPlans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoadTrainingPlans.Location = new System.Drawing.Point(381, 155);
            this.btnLoadTrainingPlans.Name = "btnLoadTrainingPlans";
            this.btnLoadTrainingPlans.Size = new System.Drawing.Size(75, 23);
            this.btnLoadTrainingPlans.TabIndex = 19;
            this.btnLoadTrainingPlans.Text = "Load Training Plans";
            this.btnLoadTrainingPlans.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDelete.Location = new System.Drawing.Point(462, 155);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 18;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCalculate.Location = new System.Drawing.Point(300, 155);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 17;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSave.Location = new System.Drawing.Point(219, 155);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 16;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dataGridViewTrainingPlans
            // 
            this.dataGridViewTrainingPlans.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTrainingPlans.Location = new System.Drawing.Point(13, 184);
            this.dataGridViewTrainingPlans.Name = "dataGridViewTrainingPlans";
            this.dataGridViewTrainingPlans.Size = new System.Drawing.Size(517, 209);
            this.dataGridViewTrainingPlans.TabIndex = 20;
            // 
            // lblDurationWeek
            // 
            this.lblDurationWeek.AutoSize = true;
            this.lblDurationWeek.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDurationWeek.Location = new System.Drawing.Point(21, 100);
            this.lblDurationWeek.Name = "lblDurationWeek";
            this.lblDurationWeek.Size = new System.Drawing.Size(111, 19);
            this.lblDurationWeek.TabIndex = 21;
            this.lblDurationWeek.Text = "Duration Week";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(21, 130);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(191, 19);
            this.lblCost.TabIndex = 22;
            this.lblCost.Text = "Cost                         Rs.0.00";
            // 
            // nudDurationWeeks
            // 
            this.nudDurationWeeks.Location = new System.Drawing.Point(158, 99);
            this.nudDurationWeeks.Name = "nudDurationWeeks";
            this.nudDurationWeeks.Size = new System.Drawing.Size(71, 20);
            this.nudDurationWeeks.TabIndex = 23;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(317, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(213, 129);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // TrainingPlanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(542, 405);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.nudDurationWeeks);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.lblDurationWeek);
            this.Controls.Add(this.dataGridViewTrainingPlans);
            this.Controls.Add(this.btnLoadTrainingPlans);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtWeeklyFee);
            this.Controls.Add(this.txtPlanName);
            this.Controls.Add(this.lblWeeklyFee);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "TrainingPlanForm";
            this.Text = "TrainingPlanForm";
            this.Load += new System.EventHandler(this.TrainingPlanForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTrainingPlans)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDurationWeeks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblWeeklyFee;
        private System.Windows.Forms.TextBox txtPlanName;
        private System.Windows.Forms.TextBox txtWeeklyFee;
        private System.Windows.Forms.Button btnLoadTrainingPlans;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dataGridViewTrainingPlans;
        private System.Windows.Forms.Label lblDurationWeek;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.NumericUpDown nudDurationWeeks;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}